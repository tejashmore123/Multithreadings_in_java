package multithreading;

public class BankTransactionDemo {
    public static void main(String[] args) {
        // Create a bank account with an initial balance of 1000
        BankAccount account = new BankAccount(1000);

        // Create multiple deposit and withdrawal threads
        DepositThread depositThread1 = new DepositThread(account, 500);
        DepositThread depositThread2 = new DepositThread(account, 200);

        WithdrawThread withdrawThread1 = new WithdrawThread(account, 300);
        WithdrawThread withdrawThread2 = new WithdrawThread(account, 700);

        // Start all the threads
        depositThread1.start();
        depositThread2.start();
        withdrawThread1.start();
        withdrawThread2.start();

        try {
            // Wait for all threads to finish
            depositThread1.join();
            depositThread2.join();
            withdrawThread1.join();
            withdrawThread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Display the final balance
        System.out.println("Final Account Balance: " + account.getBalance());
    }
}
